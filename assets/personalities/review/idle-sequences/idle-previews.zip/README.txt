Extract this archive and open index.html in a browser, or open the GIFs directly.
These are review copies; operating assets remain the separate transparent 512x768 PNG files in the repository.
